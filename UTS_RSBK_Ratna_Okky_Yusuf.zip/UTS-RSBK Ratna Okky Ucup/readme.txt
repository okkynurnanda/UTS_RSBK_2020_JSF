--------------------------------------------------------------------------
Tugas UTS RSBK
--------------------------------------------------------------------------
anggota :

Ratna Nurul Fajriya	21120117120027
Yusuf Valent Adyatomo	21120117130046
Okky Nurnanda Pangestularas	21120117130056
--------------------------------------------------------------------------
Link :
http://ec2-52-23-251-144.compute-1.amazonaws.com:8080/uts_rsbk/
--------------------------------------------------------------------------
Instalasi pada Local Server

Import file uts_rsbk.war ke dalam Eclipse
Jalankan Server Payara
Klik kanan pada project -> Run As -> Run on server
Pada browser ketik: http://localhost:8080/uts_rsbk/formsiswa.xhtml
-------------------------------------------------------------------------